// 最大上传图片的数量
const MAX_IMG_NUM = 9
// 数据库初始化操作
const db = wx.cloud.database()
// 姓名 电话 详细信息
let len0 = ''
let len1 = ''
let len2 = ''
// 经纬度 地址
let hplat = ''
let hplon = ''
let hpsite = ''

// 表示对象 存入用户头像等信息
let userInfo = {}
Page({

  /**
   * 页面的初始数据
   */
  data: {
    modalShow: false,
    // 输入的文字个数
    wordsNum: 0,
    footerBottom: 0,
    images: [],
    selectPhoto: true,
  },
  length0(event){
    len0 = event.detail.value
    console.log('求助人姓名:', len0)
  },
  length1(event) {
    len1 = event.detail.value
    console.log('求助人电话:', len1)
  },
  length2(event) {
    len2 = event.detail.value
    console.log('详细信息:', len2)
  },
  // 获取地点信息
  getLocation() {
    let that = this
    wx.chooseLocation({
      success: (res) => {
        console.log(res)
        hpsite = res.name
        hplat = res.latitude
        hplon = res.longitude
        that.setData({
          jingwei: "经纬度：" + hplat + ", " + hplon,
          address: "  地址：" + res.address,
          name: res.name
        })
      }
    })
  },
  // 获取焦点
  onFocus(event) {
    // 模拟器获取的键盘高度为 0
    // console.log(event)
    this.setData({
      footerBottom: event.detail.height
    })
  },
  // 失去焦点
  onBlur(event) {
    // console.log(event)
    this.setData({
      footerBottom: 0
    })
  },

  onChooseImage() {
    // 还能再选几张图片
    let max = MAX_IMG_NUM - this.data.images.length
    // console.log('max', max)
    wx.chooseImage({
      count: max,
      // 图片类型 初始值, 压缩后的
      sizeType: ['original', 'compressed'],
      // 源头类型 手机相册, 相机拍照
      sourceType: ['album', 'camera'],
      // 成功以后
      success: (res) => {
        console.log(res)
        this.setData({
          images: this.data.images.concat(res.tempFilePaths)
        })
        // 还能再选几张图片
        max = MAX_IMG_NUM - this.data.images.length
        this.setData({
          selectPhoto: max <= 0 ? false : true
        })
      },
    })
  },

  // 删除点击图片
  onDelImg(event) {
    this.data.images.splice(event.target.dataset.index, 1)
    // console.log(a)
    this.setData({
      images: this.data.images
    })
    if (this.data.images.length == MAX_IMG_NUM - 1) {
      this.setData({
        selectPhoto: true,
      })
    }
  },
  // 图片预览
  onPreviewImage(event) {
    // 2/9
    wx.previewImage({
      urls: this.data.images,
      current: event.target.dataset.imgsrc,
    })
  },
  
  send() {
    // 2、数据 -> 云数据库
    // 数据库：内容、图片fileID、openid(小程序唯一标识)、昵称、头像、时间
    // 1、图片 -> 云存储 5g空间, 云存储会返回图片的 fileID 云文件ID

    // 判断是否为空
    // ---------------------------------------------------
    // trim() 去掉前后的空格
    if (len0.trim() === '') {
      // 给个提示
      wx.showModal({
        title: '请输入求助人姓名...',
        content: '',
      })
      return
    } else if (len1.trim() === '') {
      // 给个提示
      wx.showModal({
        title: '请输入求助人电话...',
        content: '',
      })
      return
    } else if (len2.trim() === '') {
      // 给个提示
      wx.showModal({
        title: '请输入求助地点...',
        content: '',
      })
      return
    }

    // ---------------------------------------------------
    // 等待界面
    wx.showLoading({
      title: '发布中...',
      // 蒙板 遮住信息, 禁止用户点击
      mask: true,
    })
    // ---------------------------------------------------

    // 存入数组 保存每一个 promise 对象
    let promiseArr = []
    // file ID 是多个, 存入 fileIds 中
    const fileIds = []

    // 图片上传 一张一张上传
    for (let i = 0, len = this.data.images.length; i < len; i++) {
      // 上传图片 是 异步操作
      let p = new Promise((resolve, reject) => {
        let item = this.data.images[i]

        // 获取图片的扩展名 正则表达式
        let suffix = /\.\w+$/.exec(item)[0]
        wx.cloud.uploadFile({
          // 云端 path
          cloudPath: 'send-fabu/' + Date.now() + '-' + Math.random() * 1000000 + suffix,
          filePath: item,
          success: (res) => {
            // 上传成功 打印出返回值
            // console.log('res:', res)
            console.log(res.fileID)
            // 在 fileIds 中追加新的 fileID 的值
            // fileIds = fileIds.concat(res.fileID)
            fileIds.push(res.fileID)
            resolve()
          },
          fail: (err) => {
            console.log(err)
            reject()
          }
        })
      })
      promiseArr.push(p)
    }
    // 存入到云数据库中
    Promise.all(promiseArr).then((res) => {
      // 向 'blog' 这个集合插入数据
      db.collection('photohelp').add({
        // 需要插入的数据
        data: {
          // 当前输入 姓名 电话 详细信息
          len0,
          len1,
          len2,
          // 经纬度 地址
          hplat,
          hplon,
          hpsite,
          // 图片
          img: fileIds,
          // 获取服务端时间
          createTime: db.serverDate(),
        }
      }).then((res) => {
        // // 隐藏等待界面
        wx.hideLoading()
        wx.showToast({
          title: '发布成功！',
        })

        // 返回 blog 页面, 并且刷新
        wx.navigateBack()
        // const pages = getCurrentPages()
        // // console.log(pages)
        // // 取到上一个页面

        // const prePage = pages[pages.length - 2]
        // console.log('prePage', prePage)
        // prePage.onPullDownRefresh()

      }).catch((err) => {
        wx.hideLoading()
        wx.showToast({
          title: '发布失败！',
        })
        console.log('err', err)
      })
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log('为什么没有用户头像信息', options)
    // 用户信息
    console.log('头像信息', options.avatarUrl)
    console.log('用户名', options.nickName)
    
    this._getUserInfo()
  },
  _getUserInfo(){
    wx.getSetting({
      success: (res) => {
        console.log(res)
        if (res.authSetting['scope.userInfo']) {
          wx.getUserInfo({
            success: (res) => {
              console.log('abcdd', res.rawData)
              userInfo = res.rawData
            }
          })
        } 
      }
    })
  },
    
  
  
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})